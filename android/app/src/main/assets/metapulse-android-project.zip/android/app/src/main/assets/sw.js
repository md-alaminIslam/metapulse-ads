/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "6b94930d965c448b7fce75299297584d"
  }, {
    "url": "pwa-512x512.png",
    "revision": "c5bbc562c27e8503b2f33495c165571d"
  }, {
    "url": "pwa-192x192.png",
    "revision": "2af586fdfc4839c233ba3a7a367713f1"
  }, {
    "url": "index.html",
    "revision": "7ef292293d3cc4b40d2e5a14adc2f4fb"
  }, {
    "url": "icon.svg",
    "revision": "b972ee27e1678c115105fd0344e38788"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "8a2aae7a07bc28ec114ed864e7f24d87"
  }, {
    "url": "assets/index-ChwxVo5v.js",
    "revision": null
  }, {
    "url": "assets/index-B_St7J4o.css",
    "revision": null
  }, {
    "url": "assets/aistudio/image_321cc3c3.png",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "8a2aae7a07bc28ec114ed864e7f24d87"
  }, {
    "url": "icon.svg",
    "revision": "b972ee27e1678c115105fd0344e38788"
  }, {
    "url": "pwa-192x192.png",
    "revision": "2af586fdfc4839c233ba3a7a367713f1"
  }, {
    "url": "pwa-512x512.png",
    "revision": "c5bbc562c27e8503b2f33495c165571d"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "6b94930d965c448b7fce75299297584d"
  }, {
    "url": "manifest.webmanifest",
    "revision": "c4979872375ff83ad8839a6d9b99dc55"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
